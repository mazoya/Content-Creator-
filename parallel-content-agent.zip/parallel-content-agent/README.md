# Parallel AI Content Generator (LangGraph + Gemini + Streamlit)

Give it one topic and it fans out into four pieces of content **in parallel**
using LangGraph, then shows them all in a Streamlit UI:

- Blog post
- X/Twitter thread
- LinkedIn post
- SEO metadata (title tag, meta description, slug, keywords)

## How the parallelism works

`content_graph.py` builds a LangGraph `StateGraph` where `START` fans out to
four independent nodes (`blog`, `twitter`, `linkedin`, `seo`) that each write
to their own key in shared state, then all four converge to `END`. LangGraph
runs nodes with no dependency on each other concurrently, so all four API
calls to Gemini fire at the same time instead of one after another.

## 1. Get a free Gemini API key

https://aistudio.google.com/apikey

## 2. Push to GitHub

```bash
cd parallel-content-agent
git init
git add .
git commit -m "Initial commit: parallel content agent"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/parallel-content-agent.git
git push -u origin main
```

`.gitignore` already excludes `.env`, so your real API key never gets committed
— only `.env.example` (a template) is tracked.

## 3. Run locally

```bash
cd parallel-content-agent
pip install -r requirements.txt
export GOOGLE_API_KEY=your_key_here   # optional, can also paste it in the UI
streamlit run app.py
```

Open the URL Streamlit prints (usually http://localhost:8501).

## 4. Deploy to Google Cloud Run

### Option A — manual, one command (fastest to a URL)

Requires the `gcloud` CLI, logged in, with a project selected.

```bash
cd parallel-content-agent
gcloud run deploy parallel-content-agent \
  --source . \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars GOOGLE_API_KEY=your_key_here
```

`gcloud run deploy --source .` builds the `Dockerfile` in Cloud Build and
deploys it automatically. When it finishes it prints a public `*.run.app` URL.

### Option B — automatic, via the included GitHub Actions workflow

`.github/workflows/deploy.yml` redeploys to Cloud Run every time you push to
`main`. One-time setup:

1. **Store the Gemini key in Secret Manager** (the workflow reads it from there,
   not from a GitHub secret directly):
   ```bash
   echo -n "your_key_here" | gcloud secrets create GOOGLE_API_KEY --data-file=-
   ```
2. **Set up Workload Identity Federation** so GitHub Actions can authenticate
   without a long-lived key — follow Google's guide:
   https://github.com/google-github-actions/auth#setup (there's a
   `gcloud` script near the top that does it in a few commands).
3. **Add these repo secrets** (Settings → Secrets and variables → Actions):
   - `WIF_PROVIDER` — the provider resource name from step 2
   - `WIF_SERVICE_ACCOUNT` — the service account email from step 2
   - `GCP_PROJECT_ID` — your Google Cloud project ID
4. Push to `main` (or run the workflow manually from the Actions tab) —
   it builds, deploys, and prints the live URL in the job log.

**Note on the API key:** Option A's `--set-env-vars` is quickest for a personal
demo but stores the key in plain text in the service config. Option B uses
Secret Manager from the start, which is the safer default once this is public.

## Extending it

- Add more parallel nodes (e.g. Instagram caption, email newsletter) by
  copying the pattern of `generate_blog` in `content_graph.py` and wiring it
  into `build_graph()`.
- Swap `gemini-2.0-flash` for a stronger Gemini model in `get_llm()` if you
  want higher quality at the cost of latency/price.
- Add a review/critique node after the parallel ones (edges from each content
  node into a single "editor" node before `END`) if you want a pass that
  checks brand voice consistency across all four outputs.
